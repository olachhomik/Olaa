# Title 

SAP Build Work Zone Standard

# Description 

Reference Architecture of Workzone standard 

# Image 

 
![image](https://github.com/user-attachments/assets/9d103fe5-adc1-4e89-a178-b63cfe06cee3)


# Tags 

WorkZone Build


[Open Diagram in the browser](https://app.diagrams.net/?create=https://raw.githubusercontent.com/rsletta/sap_btp_icons_drawio_lib/main/src/templates/SAPBuildWorkZoneStandard/WorkzoneStandard.xml&clibs=Uhttps://raw.githubusercontent.com/rsletta/sap_btp_icons_drawio_lib/main/libs/SAP_BTP_Service_Icons_latest.xml)

## Desktop Client Draw.io

To use in desktop client use the following link and import with template url: 

https://raw.githubusercontent.com/rsletta/sap_btp_icons_drawio_lib/main/src/templates/SAPBuildWorkZoneStandard/Workzone Standard.xml&clibs=Uhttps://raw.githubusercontent.com/rsletta/sap_btp_icons_drawio_lib/main/libs/SAP_BTP_Service_Icons_latest.xml
